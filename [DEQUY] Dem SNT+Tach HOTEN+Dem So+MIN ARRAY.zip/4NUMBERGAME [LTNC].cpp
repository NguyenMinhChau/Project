#include<iostream>
using namespace std;
int getDiff(int a, int b){
    return a>b?a-b:b-a;
}
void getNewSquare(int &A, int &B, int &C, int &D){
    int AB, BC, CD, DA;
    AB = getDiff(A,B);
    BC = getDiff(B,C);
    CD = getDiff(C,D);
    DA = getDiff(D,A);
    A = AB; B = BC; C = CD; D = DA;
}

void print(int A, int B, int C, int D){
    cout<<A<<" "<<B<<" "<<C<<" "<<D<<endl;
}

int Try(int a, int b, int c, int d){
    if(a==0 && b==0 && c==0 && d==0) return 0;
    getNewSquare(a,b,c,d);
    print(a,b,c,d);
    return 1 + Try(a,b,c,d);
}

int main(){
    int a, b, c, d;
    cin>>a>>b>>c>>d;
    cout<<Try(a,b,c,d);
    return 0;
}


