#include<iostream>
#include<cstring>
#include<cctype>
#include<string>
using namespace std;

void normalize(char* s){
    //remove space at top
    while(isspace(s[0])){
        strcpy(s,s+1); //remove the 1st character
    }
    //remove space at bottom
    while(isspace(s[strlen(s)-1])){
        s[strlen(s)-1] = '\0'; //remove the last character
    }
    //remove space at middle
    for(int i = 0; i<strlen(s); i++){
        if(isspace(s[i])){
            while(s[i+1] != '\0' && isspace(s[i+1])){
                strcpy(s+i,s+i+1); //remove the ith character
            }
        }
    }
}

void normalize2(string& s){
    //remove space at top
    while(isspace(s[0])){
        s.erase(s.begin()); //remove the 1st character
    }
    //remove space at bottom
    while(isspace(s[s.length()-1])){
        s.erase(s.end()); //remove the last character
    }
    //remove space at middle
    for(int i = 0; i<s.length()-1; i++){
        if(isspace(s[i])){
            while(isspace(s[i+1])){
                s.erase(s.begin() + i + 1); //remove the ith character
            }
        }
    }
}

int CountNumberInString(char* s){
    int len = strlen(s);
    int count = 0;
    normalize(s); //trimming string s
    for(int i=0; i<len; i++){
        if(isspace(s[i])){
            count++;
        }
    }
    return count+1;
}

#define MAX 256
int main(){
    char s1[MAX];
    while(cin.getline(s1,MAX-1)){
        cout<<CountNumberInString(s1)<<endl;
    };
    /*string s2;
    while(getline(cin,s2)){
        normalize2(s2);
        cout<<s2<<endl;
    }*/
    return 0;
}

