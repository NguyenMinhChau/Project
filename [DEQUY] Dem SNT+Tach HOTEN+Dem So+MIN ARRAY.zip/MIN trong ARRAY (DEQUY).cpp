#include<iostream>
using namespace std;

//ham de quy tim phan tu nho nhat trong mang
int Min(int A[], int n);
int min(int a, int b);

int main(){
    int A[100];
    int n = 0;
    while(cin>>A[n]) n++;
    cout<<Min(A,n);
    return 0;
}

//ham de quy tim phan tu nho nhat trong mang
int Min(int A[], int n){
    if(n==1) return A[0];
    else return min(Min(A,n-1),A[n-1]);
}

int min(int a, int b){
    return a<b?a:b;
}

