#include<iostream>
#include<string>
using namespace std;
int main(){
    string full;
    getline(cin,full);
    int first_space, last_space;
    first_space = full.find(" "); //vi tri cua khoang trang dau tien
    last_space = full.find_last_of(" "); //vi tri cua khoang trang cuoi cung
    string ho = full.substr(0,first_space);
    string ten = full.substr(last_space+1);
    string dem;
    if(first_space == last_space) dem = "";
    else dem = full.substr(first_space+1, last_space - first_space);
    
    cout<<ho<<endl;
    if(dem != "") cout<<dem<<endl;
    cout<<ten;
    return 0;
}

