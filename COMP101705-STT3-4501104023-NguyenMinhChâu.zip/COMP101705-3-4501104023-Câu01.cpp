#include<iostream>
using namespace std;
class PS{
private:
    int tu,mau;
public:
    PS(int tu = 0, int mau = 1){
        this->tu = tu; this->mau = mau;
    }
    PS(const PS& p){
        this->tu = p.tu; this->mau = p.mau;
    }
    ~PS(){}
    int getTu(){return tu;}
    int getMau(){return mau;}
    void setTu(int tu){this->tu = tu;}
    void setMau(int mau){this->mau = mau;}
    friend istream& operator>>(istream&, PS&);
    friend ostream& operator<<(ostream&, const PS&);
    void Nghichdao(PS a);
    PS Toigian();
    float Giatri ();
    void Cong(PS &ps){
    	float a=tu+ps.mau;
    	cout<<a<<endl;
    }	
    void Print(){
    if (mau!=0 && tu!=0) cout<<tu<<"/"<<mau<<endl;
    else if (tu==0 && mau!=0) cout<<"0 vi Tu nhap bang 0"<<endl;
    else if (tu!=0 && mau==0) cout<<"0 vi Mau nhap bang 0"<<endl;
}				 
    
    
};

int main(){
    PS p1, p2;
    cin>>p1>>p2;
    cout<<p1<<p2;
    p1.Cong(p2);
    p1.Giatri(); cout<<" ";
    p2.Giatri(); cout<<endl;
    p1.Toigian(); p1.Print(); 
	p2.Toigian(); p2.Nghichdao(p2);   
	return 0;
}

istream& operator>>(istream& cin, PS& p){
    cin>>p.tu>>p.mau;
    return cin;
}
ostream& operator<<(ostream& cout, const PS& p){
    cout<<p.tu<<"/"<<p.mau<<endl;
    return cout;
}
void PS::Nghichdao(PS a){
    cout<<mau<<"/"<<tu<<endl;
}
PS PS::Toigian(){
    int a=tu;
	int b=mau;
	while (b>0){
	    int d=a%b;
		a=b;
		b=d;
	}
	tu=tu/a;
	mau=mau/a;	   
}
float PS::Giatri(){
	printf ("%.3f", (float) tu/mau);
}




