#include<iostream>
using namespace std;
int UCLN(int a, int b) {
    if (b == 0) return a;
    return UCLN(b, a % b);
}
class PS {
public:
    int tu, mau;
    int n;
public:
    PS(int tu = 0, int mau = 1) {
        this->tu = tu; this->mau = mau;
    }
    PS(const PS& p) {
        this->tu = p.tu; this->mau = p.mau;
    }
    ~PS() {}
    int getTu() { return tu; }
    int getMau() { return mau; }
    void setTu(int tu) { this->tu = tu; }
    void setMau(int mau) { this->mau = mau; }
    friend istream& operator>>(istream&, PS&);
    friend ostream& operator<<(ostream&, const PS&);
    PS Nghichdao();
    PS Toigian();
    PS operator+(const PS&);
    PS operator-(const PS&);
    PS operator*(const PS&);
    PS operator/(const PS&);
    operator double();
};
int main() {
    int n,m;
    cin >> n >> m;
    PS a[100];
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    PS min, max, tong, hieu, tich, thuong;
    min = a[0];
    max = a[0];
    for (int i = 1; i < n; i++) {
        if (min < a[i]) min = a[i];
        if (max > a[i]) max = a[i];
    }
    if (m == 0) {
        tong = a[0];
        tich = max*min;
        for (int i = 1; i < n; i++) {
            tong = tong + a[i];
        }
        cout << tong << tich;
    }
    else if (m == 1) {
        hieu = a[0];
        thuong = max / min;
        for (int i = 1; i < n; i++) {
            tong = tong - a[i];
        }
        cout << hieu  << thuong;
    }
    return 0;
}
istream& operator>>(istream& cin, PS& p) {
    cin >> p.tu >> p.mau;
    return cin;
}
ostream& operator<<(ostream& cout, const PS& p) {
    int x = UCLN(p.tu, p.mau);
    cout << p.tu/x << "/" << p.mau/x << endl;
    return cout;
}
PS PS::Nghichdao() {
    PS ret(this->mau, this->tu);
    return ret;
}
PS PS::Toigian() {
    int a = tu;
    int b = mau;
    while (b > 0) {
        int d = a % b;
        a = b;
        b = d;
    }
    tu = tu / a;
    mau = mau / a;
    return *this;
}
PS PS::operator+(const PS& p) {
    PS ret(this->tu * p.mau + this->mau * p.tu, this->mau * p.mau);
    return ret;
}
PS PS::operator-(const PS& p) {
    PS ret(this->tu * p.mau - this->mau * p.tu, this->mau * p.mau);
    return ret;
}
PS PS::operator*(const PS& p) {
    PS ret(this->tu * p.tu, this->mau * p.mau);
    return ret;
}
PS PS::operator/(const PS& p) {
    PS ret(this->tu * p.mau, this->mau * p.tu);
    return ret;
}
PS::operator double() {
    return (double)this->tu / this->mau;
}
