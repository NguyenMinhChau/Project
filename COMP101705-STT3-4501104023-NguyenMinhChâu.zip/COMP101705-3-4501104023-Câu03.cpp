#include<iostream>
using namespace std;
int UCLN(int a, int b) {
    if (b == 0) return a;
    return UCLN(b, a % b);
}
class PS {
private:
    int tu, mau;
public:
    PS(int tu = 0, int mau = 1) {
        this->tu = tu; this->mau = mau;
    }
    PS(const PS& p) {
        this->tu = p.tu; this->mau = p.mau;
    }
    ~PS() {}
    int getTu() { return tu; }
    int getMau() { return mau; }
    void setTu(int tu) { this->tu = tu; }
    void setMau(int mau) { this->mau = mau; }
    friend istream& operator>>(istream&, PS&);
    friend ostream& operator<<(ostream&, const PS&);
    PS Nghichdao();
    PS Toigian();
    PS operator+(const PS&);
    PS operator-(const PS&);
    PS operator*(const PS&);
    PS operator/(const PS&);
    operator double();
    int operator[](int index) {
        if (index == 0) return tu;
        else return mau;
    };
    PS operator++();
    PS operator++(int);
    PS operator--();
    PS operator--(int);
};
int main() {
    int x, y;
    cin >> x >> y;
    PS p1, p2;
    cin >> p1 >> p2;
    cout << p1[x] << endl;
    cout << p2[y]<<endl;
    cout << --p1 + p2++<<endl;
    cout << p1++ - ++p2;
    return 0;
}
istream& operator>>(istream& cin, PS& p) {
    cin >> p.tu >> p.mau;
    int x = UCLN(p.tu, p.mau);
    p.tu /= x;
    p.mau /= x;
    return cin;
}
ostream& operator<<(ostream& cout, const PS& p) {
    cout << p.tu << "/" << p.mau;
    return cout;
}
PS PS::Nghichdao() {
    PS ret(this->mau, this->tu);
    return ret;
}
PS PS::Toigian() {
    int a = tu;
    int b = mau;
    while (b > 0) {
        int d = a % b;
        a = b;
        b = d;
    }
    tu = tu / a;
    mau = mau / a;
    return *this;
}
PS PS::operator+(const PS& p) {
    PS ret(this->tu * p.mau + this->mau * p.tu, this->mau * p.mau);
    return ret;
}
PS PS::operator-(const PS& p) {
    PS ret(this->tu * p.mau - this->mau * p.tu, this->mau * p.mau);
    return ret;
}
PS PS::operator*(const PS& p) {
    PS ret(this->tu * p.tu, this->mau * p.mau);
    return ret;
}
PS PS::operator/(const PS& p) {
    PS ret(this->tu * p.mau, this->mau * p.tu);
    return ret;
}
PS::operator double() {
    return (double)this->tu / this->mau;
}
PS PS::operator++() {
    tu = tu + 1;
    return *this;
}
PS PS::operator++(int) {
    PS ret = *this;
    tu = tu + 1;
    return ret;
}
PS PS::operator--() {
    tu = tu - 1;
    return *this;
}
PS PS::operator--(int) {
    PS ret = *this;
    tu = tu - 1;
    return ret;
}
