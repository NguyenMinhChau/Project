#include<iostream>
#include <cmath>
using namespace std;
class PS{
private:
    int tu,mau;
public:
    PS(int tu = 0, int mau = 1){
        this->tu = tu; this->mau = mau;
    }
    PS(const PS& p){
        this->tu = p.tu; this->mau = p.mau;
    }
    ~PS(){}
    int getTu(){return tu;}
    int getMau(){return mau;}
    void setTu(int tu){this->tu = tu;}
    void setMau(int mau){this->mau = mau;}
    friend istream& operator>>(istream&, PS&);
    friend ostream& operator<<(ostream&, const PS&);
    PS Nghichdao();
    PS Rutgon();
    PS operator+(const PS&);
    PS operator-(const PS&);
    PS operator*(const PS&);
    PS operator/(const PS&);
    bool operator==(const PS&);
    bool operator>(const PS&);
    bool operator<(const PS&);
    operator double();
    PS operator++();
    PS operator++(int);
    PS operator--();
    PS operator--(int);
    void honSo(){
		cout<<(int)(tu/mau)<<" "<<abs(tu)-abs(mau)<<"/"<<mau<<endl;
	}
};

int TimUCLN(int a, int b){
    while(a!=b){
        if(a>b) a-=b; else b-=a;
    }
    return a;
}

int main(){
    PS p1, p2;
    cin>>p1>>p2;
    p1.Rutgon(); p2.Rutgon();
    PS p3=p1+p2; p3.Rutgon();
    (p3).honSo(); 
	if(p1>p2) cout<<">";
	else if(p1<p2) cout<<"<";
	else if(p1==p2) cout<<"=";
    return 0;
}

istream& operator>>(istream& cin, PS& p){
    cin>>p.tu>>p.mau;
    return cin;
}
ostream& operator<<(ostream& cout, const PS& p){
    cout<<p.tu<<"/"<<p.mau;
    return cout;
}
PS PS::Nghichdao(){
    PS ret(this->mau,this->tu);
    return ret;
}
PS PS::Rutgon(){
    int uc = TimUCLN(this->tu,this->mau);
    this->tu/=uc; this->mau/=uc;
    return *this;
}
PS PS::operator+(const PS& p){
    PS ret(this->tu*p.mau+this->mau*p.tu,this->mau*p.mau);
    return ret;
}
PS PS::operator-(const PS& p){
    PS ret(this->tu*p.mau-this->mau*p.tu,this->mau*p.mau);
    return ret;
}
PS PS::operator*(const PS& p){
    PS ret(this->tu*p.tu,this->mau*p.mau);
    return ret;
}
PS PS::operator/(const PS& p){
    PS ret(this->tu*p.mau,this->mau*p.tu);
    return ret;
}
bool PS::operator==(const PS& p){
    return (this->tu*p.mau)==(this->mau*p.tu);
}
bool PS::operator>(const PS& p){
    return (this->tu*p.mau)>(this->mau*p.tu);
}
bool PS::operator<(const PS& p){
    return (this->tu*p.mau)<(this->mau*p.tu);
}
PS::operator double(){
    return (double)this->tu/this->mau;
}
PS PS::operator++(){
    tu = tu+mau;
    return *this;
}
PS PS::operator++(int){
    PS ret = *this;
    tu = tu+mau;
    return ret;
}
PS PS::operator--(){
    tu = tu-mau;
    return *this;
}
PS PS::operator--(int){
    PS ret = *this;
    tu = tu-mau;
    return ret;
}


