#include <iostream>
#include <fstream>
#include<iomanip>
using namespace std;
const int MAX=100;
int	visited[MAX];
int	nSoMienLienThong;
struct GRAPH 
{ 
	int sodinh;//so dinh do thi
	int a[MAX][MAX];//ma tran ke	
};
//Ham duyet theo chieu sau
void visit(GRAPH g, int i, int nLabel)
{
	visited[i] = nLabel; 
	for (int j=0; j < g.sodinh; j++)
	if ((visited[j] == 0) && (g.a[i][j] != 0))
		visit(g, j, nLabel);
}
//Ham xet tinh lien thong
void XetLienThong(GRAPH& g)
{
	for(int i=0; i < g.sodinh; i++)
		visited[i] = 0;
	nSoMienLienThong = 0;

	for (int i=0; i<g.sodinh; i++)
	if (visited[i] == 0){
		nSoMienLienThong ++;
    visit(g, i, nSoMienLienThong);
	}		
}
//Ham in so thanh phan lien thong
void InThanhPhanLienThong(GRAPH  g){
	cout<<"So mien lien thong: "<<nSoMienLienThong <<endl;
	for (int i=1; i<= nSoMienLienThong ; i++)
	{
		cout<<"Mien lien thong thu "<<i<<endl;
		for (int j=0; j<g.sodinh; j++)
		if (visited[j] == i)
			cout<<setw(4)<<j;
		
		cout<<endl;
	}
}
void XuatMTKe(GRAPH &g){
	cout<<"So dinh cua do thi: "<<g.sodinh;
	printf("\nMa tran ke:\n");
	for (int i = 0; i<g.sodinh; i++){
		for (int j = 0; j<g.sodinh; j++)
			printf("%3d ", g.a[i][j]);
		printf("\n");
	}
}
int main(){
	GRAPH g;
	FILE *f = fopen("Lab02_Xet_Tinh_Lien_Thong.txt", "rt");
	if (f == NULL){
		printf("Doc file loi !!!");
		return 0;
	}
	fscanf(f, "%d", &g.sodinh);
	for (int i = 0; i<g.sodinh; i++)	{
		for (int j = 0; j<g.sodinh; j++){
			fscanf(f, "%d", &(g.a[i][j]));
		}
	}
	XuatMTKe(g);
	XetLienThong(g);
    if(nSoMienLienThong > 1)
        cout<< "KHONG LIEN THONG"<<endl;
    else
        cout<< "LIEN THONG"<<endl;
    
    cout<< nSoMienLienThong <<endl;
    
    InThanhPhanLienThong(g);
	return 0;
}	

