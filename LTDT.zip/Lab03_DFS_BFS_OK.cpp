
#include <iostream>
#include <iomanip>
using namespace std;

const int MAX = 100; //so dinh toi da cua do thi

 
//Do thi gom co so dinh va ma tran ke. 
struct GRAPH 
{ 
	int sodinh;//so dinh do thi
	int a[MAX][MAX];//ma tran ke
	
	int LuuVet[MAX];//LuuVet[j] = i nghia l� tru?c d?nh j l� d?nh i.
    int visited[MAX];//danh dau dinh duyet hay chua
}; 

void printGRAPH (GRAPH g){
cout<<"So dinh cua do thi: "<<g.sodinh<<endl;
	for(int i=0;i<g.sodinh;i++)
	{
		for(int j=0;j<g.sodinh;j++)
			cout<<setw(4)<<g.a[i][j];
		cout<<endl;
	}
	cout<<endl;
}
void DFS(int s, GRAPH &g)
{
	g.visited[s] = 1;
	for(int i = 0; i < g.sodinh; i++)
		if(g.visited[i] == 0 && g.a[s][i] != 0)
		{
			g.LuuVet[i] = s; 
			DFS(i, g);
		}
}
void duyetDFS(int s, int f, GRAPH &g)
{
	for(int i = 0; i < g.sodinh; i++)
	{
		g.visited[i] = 0;
		g.LuuVet[i] = -1;
	}
	DFS(s, g);

	if(g.visited[f] == 1)
	{
		int j = f;
		while(j != s)
		{
			cout<<j<<" <--- ";			
			j = g.LuuVet[j];
		}
		cout<<s;
		cout<<endl;
	}
	else
		cout<<"Khong co duong di tu dinh "<<s<<" den dinh "<<f;
	cout<<endl;
}
 struct QUEUE{
	int size;
	int a[MAX];
};
void KhoiTao(QUEUE &q){ q.size = 0;}
bool Them(int k, QUEUE &q)
{
	if(q.size + 1 > MAX) return false;
	q.a[q.size] = k;
	q.size++;
	return true;
}
bool KiemTraRong(QUEUE q)
{
	return (q.size == 0);
}
bool Lay(int &v, QUEUE &q)
{
	if(KiemTraRong(q)) return false;
	v = q.a[0];
	for(int i = 0; i < q.size - 1; i++)
		q.a[i] = q.a[i+1];
	q.size--;
	return true;
}

void BFS(int s, GRAPH &g)
{
	QUEUE q;
	KhoiTao(q);
	Them(s, q);

	while(!KiemTraRong(q))
	{
		Lay(s, q);
		g.visited[s] = 1;
		for(int i = 0; i < g.sodinh; i++)
		if(g.visited[i] == 0 && g.a[s][i] != 0){
			Them(i, q); 		g.LuuVet[i] = s;			
		}
	}	
}
void duyetBFS(int s, int f, GRAPH &g)
{
	for(int i = 0; i < g.sodinh; i++)
	{
		g.visited[i] = 0;
		g.LuuVet[i] = -1;
	}
	BFS(s, g);

	if(g.visited[f] == 1)
	{
		int j = f;
		while(j != s)
		{
			cout<<j<<" <--- ";			
			j = g.LuuVet[j];
		}
		cout<<s;
		cout<<endl;
	}
	else
		cout<<"Khong co duong di tu dinh "<<s<<" den dinh "<<f;
	cout<<endl;
}
void XuatMTKe(GRAPH &g){
	cout<<"So dinh cua do thi: "<<g.sodinh;
	printf("\nMa tran ke:\n");
	for (int i = 0; i<g.sodinh; i++){
		for (int j = 0; j<g.sodinh; j++)
			printf("%3d ", g.a[i][j]);
		printf("\n");
	}
}
 int main(){
    GRAPH g;
	FILE *f = fopen("Lab03_DFS_BFS.txt", "rt");
	if (f == NULL){
		printf("Doc file loi !!!");
		return 0;
	}
	fscanf(f, "%d", &g.sodinh);
	for (int i = 0; i<g.sodinh; i++)	{
		for (int j = 0; j<g.sodinh; j++){
			fscanf(f, "%d", &(g.a[i][j]));
		}
	}
	XuatMTKe(g);
    
    cout<<"Duyet theo chieu sau DFS:"<<endl<<endl;
    duyetDFS(1, 4, g);
    duyetDFS(0, 4, g);
    duyetDFS(3, 2, g);
    duyetDFS(2, 4, g);
    
    cout<<"Duyet theo chieu rong BFS:"<<endl<<endl;;
    duyetBFS(1, 4, g);
    duyetBFS(0, 4, g);
    duyetBFS(3, 2, g);
    duyetBFS(2, 4, g);
    
    return 0;
 }

