#include <iostream>
#include <fstream>
#include <queue>
#include<iomanip>
#include<conio.h>
using namespace std;
const int MAX = 100; //so dinh toi da cua do thi
int visited[MAX]; 
int	nSoMienLienThong;
//Do thi gom co so dinh va ma tran ke. 
struct GRAPH 
{ 
	int sodinh;//so dinh do thi
	int a[MAX][MAX];//ma tran ke
	
}; 
//Ham Kiem Tra Tinh Hop Le Cua Do Thi (Duong cheo chinh bang 0)
int KiemTraMaTranKeHopLe(GRAPH &g)
{
	// kiem tra c�c gi� tri a[0][0], a[1][1], � xem c� gi� tri kh�c 0 hay kh�ng
	// neu c�, nghia l� ma tran ke kh�ng hop le
	for (int i=0; i<g.sodinh; i++)
	if (g.a[i][i] != 0)
		return 0;
	return 1;
}
//Ham Kiem Tra Do Thi Co Huong Hay Vo Huong
int KiemTraDoThiVoHuong(GRAPH &g)
{
	// kiem tra xem c�c gi� tri a[i][j] c� bang voi a[j][i] hay kh�ng
	// neu c�, nghia l� do thi kh�ng doi xung
	int i, j;
	for (i=0; i<g.sodinh; i++)		// c� the giam bot c�c buoc kiem tra thua voi
	for (j=0; j<g.sodinh; j++)		// for (j=i+1; j<n; j++)
	if (g.a[i][j] != g.a[j][i])		
		return 0;
	return 1;
}
//Ham Xuat Ma Tran Ke
void XuatMTKe(GRAPH &g){
	cout<<"So dinh cua do thi: "<<g.sodinh;
	printf("\nMa tran ke:\n");
	for (int i = 0; i<g.sodinh; i++){
		for (int j = 0; j<g.sodinh; j++)
			printf("%3d ", g.a[i][j]);
		printf("\n");
	}
}
//Ham Tinh Tong Bac
int TongBac(GRAPH &g){
	int Tong=0;
	for(int i=0;i<g.sodinh;i++){
		for(int j=0;j<g.sodinh;j++){
			if(g.a[i][j] > 0){
			    Tong++; 
			}
		}
	}
	return Tong;		    
}	
//Ham Tinh Canh Cua Do Thi
int TinhCanh(GRAPH &g){
	int a= TongBac(g);
	int canh=a/2;
	return canh;
}	
//Ham Tim Dinh lien Thong
void TimDinhLienThong(GRAPH &g, int x){
	cout<<"Cac dinh lien thong voi dinh "<<x<<" la:";
	for (int i=1 ; i<=g.sodinh ; i++)
	{
		if (g.a[x][i] != 0)
		{
			cout<<" "<<i<<" ";
		}
	}
	cout<<endl;
}	
//Ham Tim Bac Lon Nhat
int BacLonNhat(GRAPH &g) {
   int max = 0,Bac;
   for(int i = 0; i<g.sodinh; i++) {
      Bac = 0;
      for(int j = 0; j<g.sodinh; j++)
      if(g.a[i][j]>0)         //T�nh bac cua tung dinh
         Bac++;
      if(Bac > max)    max = Bac;
   }
   return max;            //Tra ve bac lon nhat   
}
//Ham Tim Bac Nho Nhat
int BacNhoNhat(GRAPH &g) {
   int min = 0,Bac;
   for(int i = 0; i<g.sodinh; i++) {
      Bac = 0;
      for(int j = 0; j<g.sodinh; j++)
      if(g.a[i][j]>0)         //T�nh bac cua tung dinh
         Bac++;
      if(Bac < min)    min = Bac;
   }
   return min;            //Tra ve bac lon nhat   
}
//Ham liet ke cac dinh co bac nho nhat
void DinhBacNhoNhat(GRAPH &g){
   int min = BacNhoNhat(g), Bac;
   for(int i = 0; i<g.sodinh; i++) {
      Bac = 0;
      for(int j = 0; j<g.sodinh; j++)
      if(g.a[i][j]>0)
         Bac++;
      if(Bac == min)
         cout<<" "<<i+1;
   }
}
//Ham liet ke cac dinh c� bac lon nhat
void DinhBacLonNhat(GRAPH &g){
   int max = BacLonNhat(g), Bac;
   for(int i = 0; i<g.sodinh; i++) {
      Bac = 0;
      for(int j = 0; j<g.sodinh; j++)
      if(g.a[i][j]>0)
         Bac++;
      if(Bac == max)
         cout<<" "<<i+1;
   }
}
//Ham liet ke cac dinh bac chan v� so dinh bac chan
void DinhBacChan(GRAPH &g) {
   int Bac,Tong=0;
   cout<<"Cac dinh bac chan la:";
   for(int i = 0; i<g.sodinh; i++) {
      Bac = 0;
      for(int j = 0; j<g.sodinh; j++)
      if(g.a[i][j]>0)
         Bac++;
      if(Bac%2==0) {
         cout<<" "<<i+1;
         Tong++;
      }
   }
   cout<<"\nSo Dinh Bac Chan: "<<Tong;
}
//Ham liet ke cac dinh bac le va so dinh bac le
void DinhBacLe(GRAPH &g){
   int Bac,Tong=0;
   cout<<"Cac dinh bac le la:";
   for(int i = 0; i<g.sodinh; i++) {
      Bac = 0;
      for(int j = 0; j<g.sodinh; j++)
      if(g.a[i][j]>0)
         Bac++;
      if(Bac%2==1) {
         cout<<" "<<i+1;
         Tong++;
      }
   }
   cout<<"\nSo Dinh Bac Le: "<<Tong;
}
int main (){
   GRAPH g;
   FILE *f = fopen("Lab01_LTDT.txt", "rt");
	if (f == NULL){
		printf("Doc file loi !!!");
		return 0;
	}
	fscanf(f, "%d", &g.sodinh);
	for (int i = 0; i<g.sodinh; i++)	{
		for (int j = 0; j<g.sodinh; j++){
			fscanf(f, "%d", &(g.a[i][j]));
		}
	}
   
   XuatMTKe(g);
   cout<<"\t\t\tKIEM TRA TINH CHAT CUA MA TRAN KE"<<endl;
   if(!KiemTraMaTranKeHopLe(g)){
   	   cout<<"Ma tran tren khong hop le!"<<endl;
   	   //exit(0);
   	}  
	else{
		cout<<"Ma tran tren hop le!"<<endl;
	} 
	
	if(!KiemTraDoThiVoHuong(g)){
   	   cout<<"Day la ma tran co huong!"<<endl;
   	   //exit(0);
   	}  
	else{
		cout<<"Day la ma tran vo huong!"<<endl;
	} 
	cout<<"Tong Bac cua Do Thi = "<<TongBac(g)<<endl;
	cout<<"So canh cua Do Thi = "<<TinhCanh(g)<<endl;
	int x; cout<<"Nhap vao dinh ban muon tim: "; cin>>x;
	TimDinhLienThong(g,x);
	cout<<"Bac lon nhat cua Do Thi = "<<BacLonNhat(g)<<endl;
	cout<<"Bac nho nhat cua Do Thi = "<<BacNhoNhat(g)<<endl;
	cout<<"Cac dinh co bac nho nhat cua Do Thi:"; DinhBacNhoNhat(g); cout<<endl;
	cout<<"Cac dinh co bac lon nhat cua Do Thi:"; DinhBacLonNhat(g); cout<<endl;
	DinhBacChan(g); cout<<endl;
	DinhBacLe(g); cout<<endl;
    //cout<<"Xet tinh lien thong: "<<XetLienThong(g);
	return 0;
}

