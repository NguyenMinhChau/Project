#include <iostream> 
using namespace std; 
 
#define MAX 20 
#define FOUND 1 
#define NOT_FOUND 0 
int b[MAX], c[MAX]; 
struct GRAPH 
{ 
	int sodinh; 
	int a[MAX][MAX]; 
};
//Ham tuong tu DFS
int visit(int u, int visited[],int&count,int&flag, int path[], GRAPH g) { 
	if(flag == FOUND)  return flag;  
	for(int v = 0; v < g.sodinh; v++){
		if(visited[v] == 0 && g.a[u][v] != 0) {  
			visited[v] = 1;  
			path[count] = v;  
			count++;  
			if(count == g.sodinh && g.a[v][path[0]] == 1)
				flag = FOUND;  
			visit(v,visited,count,flag,path, g);  
		}
	}	  
}
//Ham tim chu trinh Hamilton _ Xet co phai la chu trinh Hamilton khong
int dfsHamilton(int path[], GRAPH g) 
{ 
	int start = 0;  
	int flag = NOT_FOUND; 
	int visited[MAX]; 
 
	for(int i = 0; i < g.sodinh; i++) {  
		visited[i] = 0;  
	}  
 
	int count = 0;   
	path[count] = start;  
	count++;  
	visited[start] = 1;  
 
	flag = visit(start,visited,count,flag,path,g);  
 
	if(flag) return 	FOUND;  
	return 		NOT_FOUND;  
} 
void showpath(GRAPH &g)
{
    for (int k=0; k < g.sodinh; k++) printf("%4d",c[k]+1);
    printf("%4d\n",c[0]+1);
}
void Hamilton(GRAPH &g,int j)
{
    for (int k = 0; k < g.sodinh; k++)
        if (b[k]==0 && g.a[c[j-1]][k])
        {
            b[k] = 1; c[j] = k;
            if (j==g.sodinh-1)
            {
                if(g.a[c[j]][c[0]])showpath(g);
            }
            else Hamilton(g,j+1);
            b[k] = 0;
        }
}
void XuatMTKe(GRAPH &g){
	cout<<"So dinh cua do thi: "<<g.sodinh;
	printf("\nMa tran ke:\n");
	for (int i = 0; i<g.sodinh; i++){
		for (int j = 0; j<g.sodinh; j++)
			printf("%3d ", g.a[i][j]);
		printf("\n");
	}
}
int main(){
	GRAPH g;
	FILE *f = fopen("Lab08_ChuTrinh_DuongDi_Hamilton.txt", "rt");
	if (f == NULL){
		printf("Doc file loi !!!");
		return 0;
	}
	fscanf(f, "%d", &g.sodinh);
	for (int i = 0; i<g.sodinh; i++)	{
		for (int j = 0; j<g.sodinh; j++){
			fscanf(f, "%d", &(g.a[i][j]));
		}
	}
	XuatMTKe(g);
	int path[MAX];  
	cout<<"Tat ca chu trinh Hamilton:"<<endl;
	if(dfsHamilton(path, g) == FOUND)  
	{  
		// T�m c�ch in ra chu tr�nh Hamilton dua v�o mang path
		Hamilton(g,1);
    }
	else  
		cout<<"Khong tim thay chu trinh Hamilton";  
	system("pause");

	return 0;
}	
