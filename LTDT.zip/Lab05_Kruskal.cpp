#include <iostream>
#include <iomanip>
using namespace std;

const int MAX = 100; //so dinh toi da cua do thi

 
//Do thi gom co so dinh va ma tran ke. 
struct GRAPH 
{ 
	int sodinh;//so dinh do thi
	int a[MAX][MAX];//ma tran ke
	int visited[MAX]; //danh dau dinh i da xet hay chua, 0 la chua xet
}; 
struct CANH
{
	int u;//Dinh thu nhat
    int v;//Dinh thu hai
	int trongso;
};
CANH T[MAX];
void KhoiTaoMangCanh(GRAPH g, int &nCanh, CANH DSCanh[]){
     
 }
 void SapXepCanh(int nCanh,CANH DSCanh[], GRAPH g){
     
 }
 bool CoChuTrinh(GRAPH g, int iMin,CANH DSCanh[], int Nhan[]) {
     
    return true;
 }
 void Kruskal(GRAPH g, int &nT, CANH T[]) 
{ 
	int nCanh; 
	int Nhan[100]; 
	CANH DSCanh[100]; 
	KhoiTaoMangCanh(g, nCanh, DSCanh); 
	SapXepCanh(nCanh, DSCanh, g); 
	nT = 0; 
	for(int i=0; i< g.sodinh; i++) 
	{ 
		Nhan[i] = i; 
	} 

	int iMin = 0;
	while(nT < g.sodinh - 1) { 
		if(iMin < nCanh){ 
			if( CoChuTrinh(g, iMin, DSCanh, Nhan) == false) { 
				T[nT] = DSCanh[iMin]; 
				nT++; 
			} 
			iMin++; 
		} 
		else { 
			break; 
		} 
	} 
} 

void XuatMTKe(GRAPH &g){
	cout<<"So dinh cua do thi: "<<g.sodinh;
	printf("\nMa tran ke:\n");
	for (int i = 0; i<g.sodinh; i++){
		for (int j = 0; j<g.sodinh; j++)
			printf("%3d ", g.a[i][j]);
		printf("\n");
	}
}
 int main(){
    GRAPH g;
	FILE *f = fopen("Lab03_DFS_BFS.txt", "rt");
	if (f == NULL){
		printf("Doc file loi !!!");
		return 0;
	}
	fscanf(f, "%d", &g.sodinh);
	for (int i = 0; i<g.sodinh; i++)	{
		for (int j = 0; j<g.sodinh; j++){
			fscanf(f, "%d", &(g.a[i][j]));
		}
	}
	XuatMTKe(g);
	cout<<"Kruskal"<<endl;
    //Kruskal(g);
	return 0;
}	
