#include <iostream>
#include <fstream>
using namespace std;
const int MAX=100;
struct GRAPH 
{ 
	int sodinh;//so dinh do thi
	int a[MAX][MAX];//ma tran ke	
	int visited[MAX]; //danh dau dinh i da xet hay chua, 0 la chua xet
};
struct CANH
{
	int u;//Dinh thu nhat
    int v;//Dinh thu hai
	int trongso;
};
CANH T[MAX];//Mang luu c�c canh trong thuat to�n Prim
//Cay khung nho nhat cua do thi
void Prim(GRAPH g)
{
	//B1: G�n so canh cua c�y khung ban dau l� 0
	int nT = 0;
	//B2: Khoi tao nh�n c�c dinh l� chua duyet (0)
	for(int i = 0; i < g.sodinh; i++)
		g.visited[i] = 0;

	//B3: ��nh dau dinh 0 l� d� duyet
	g.visited[0] = 1;
while(nT < g.sodinh - 1)//neu du n -1 canh th� dung (Tai sao, dua v�o d�u??)	
	{
		CANH canhnhonhat;//d�ng de luu tru canh nho nhat tu mot dinh d� x�t toi dinh chua x�t
		int min = -1;	//Tai sao lay -1????
		for(int i = 0; i < g.sodinh; i++)
			if(g.visited[i] == 0) //neu l� dinh chua duyet. �ieu kien d�ng khi j thuoc tap Y hay V\Y
			{
				for(int j = 0; j < g.sodinh; j++)
					if(g.visited[j] == 1 && (g.a[i][j] != 0))
					{
						if(min == -1 || g.a[i][j] < min)
						{
							min = g.a[i][j];
							canhnhonhat.u = i;
							canhnhonhat.v = j;
							canhnhonhat.trongso = g.a[i][j];
						}
					}
			}

		//Th�m canh nho nhat v�o tap T
		T[nT] = canhnhonhat;
		nT++;//tang so canh l�n 1

		g.visited[canhnhonhat.u] = 1;//Tai sao????
		
	}

	//Tong trong so cua c�y khung
	int sum = 0;
	cout<<"Cay khung nho nhat cua do thi la: ";
	for(int i = 0; i < nT; i++)
	{
		cout<<"("<<T[i].u<<", "<<T[i].v<<") ";
		sum += T[i].trongso;
	}
	cout<<endl;
	cout<<"Tong gia tri cua cay la: "<<sum<<endl;
}
//Cay khung lon nhat cua do thi
void Prim1(GRAPH g)
{
	//B1: G�n so canh cua c�y khung ban dau l� 0
	int nT = 0;
	//B2: Khoi tao nh�n c�c dinh l� chua duyet (0)
	for(int i = 0; i < g.sodinh; i++)
		g.visited[i] = 0;

	//B3: ��nh dau dinh 0 l� d� duyet
	g.visited[0] = 1;
while(nT < g.sodinh - 1)//neu du n -1 canh th� dung (Tai sao, dua v�o d�u??)	
	{
		CANH canhlonnhat;//d�ng de luu tru canh nho nhat tu mot dinh d� x�t toi dinh chua x�t
		int max = -1;	//Tai sao lay -1????
		for(int i = 0; i < g.sodinh; i++)
			if(g.visited[i] == 0) //neu l� dinh chua duyet. �ieu kien d�ng khi j thuoc tap Y hay V\Y
			{
				for(int j = 0; j < g.sodinh; j++)
					if(g.visited[j] == 1 && (g.a[i][j] != 0))
					{
						if(max == -1 || g.a[i][j] > max)
						{
							max = g.a[i][j];
							canhlonnhat.u = i;
							canhlonnhat.v = j;
							canhlonnhat.trongso = g.a[i][j];
						}
					}
			}

		//Th�m canh nho nhat v�o tap T
		T[nT] = canhlonnhat;
		nT++;//tang so canh l�n 1

		g.visited[canhlonnhat.u] = 1;//Tai sao????
		
	}

	//Tong trong so cua c�y khung
	int sum = 0;
	cout<<"Cay khung lon nhat cua do thi la: ";
	for(int i = 0; i < nT; i++)
	{
		cout<<"("<<T[i].u<<", "<<T[i].v<<") ";
		sum += T[i].trongso;
	}
	cout<<endl;
	cout<<"Tong gia tri cua cay la: "<<sum<<endl;
}
void XuatMTKe(GRAPH &g){
	cout<<"So dinh cua do thi: "<<g.sodinh;
	printf("\nMa tran ke:\n");
	for (int i = 0; i<g.sodinh; i++){
		for (int j = 0; j<g.sodinh; j++)
			printf("%3d ", g.a[i][j]);
		printf("\n");
	}
}

int main (){
   GRAPH g;
   FILE *f = fopen("Lab04_Prim.txt", "rt");
	if (f == NULL){
		printf("Doc file loi !!!");
		return 0;
	}
	fscanf(f, "%d", &g.sodinh);
	for (int i = 0; i<g.sodinh; i++)	{
		for (int j = 0; j<g.sodinh; j++){
			fscanf(f, "%d", &(g.a[i][j]));
		}
	}
	XuatMTKe(g);
	Prim(g);
	Prim1(g);
   return 0;
}

