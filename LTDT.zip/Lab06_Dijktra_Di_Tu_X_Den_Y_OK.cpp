#include <iostream>
#include <iomanip>
using namespace std;

#define MAX 100 //so dinh toi da cua do thi
#define VoCuc - 1
 
//Do thi gom co so dinh va ma tran ke. 
struct GRAPH 
{ 
	int sodinh;//so dinh do thi
	int a[MAX][MAX];//ma tran ke
}; 

bool ThuocT[MAX];//<1>
int Length[MAX];//<2>
int LastV[MAX];//<3>
void Dijkstra(GRAPH g, int x, int y)
{
	int min = -1;
	int i;

//begin <4>
	for(i = 0; i < g.sodinh; i++)
	{
		ThuocT[i] = true;
		Length[i] = VoCuc;
		LastV[i] = -1;
	}

	Length[x] = 0;
	ThuocT[x] = false;
	LastV[x] = x;
	//end <4>	

	int v = x;
	int t = x;
	while(ThuocT[y])//<5>
	{
//begin <6>
		for(int k = 0; k < g.sodinh; k++)
		{
			if(g.a[v][k] != 0 && ThuocT[k] == true && (Length[k] == VoCuc || Length[k] > Length[v] + g.a[v][k]))
			{
				Length[k] = Length[v] + g.a[v][k];
				LastV[k] = v;
			}//end if
		}//end for
		//end <6>

//begin<7>
		v = -1;
		for(i = 0; i < g.sodinh; i++)
		{
			if(ThuocT[i] == true && Length[i] != VoCuc)
				if(v == -1 || Length[v] > Length[i])
					v = i;
		}
		ThuocT[v] = false;
//end <7>
	}
}
void Xuat(int x, int y)
{
	int DuongDi[MAX];
	int v = y, i;
	int id = 0;
	while (v != x)
	{
		DuongDi[id] = v;
		v = LastV[v];
		id++;
	}
	DuongDi[id] = x;
	for(i = id; i > 0; i--)
		cout<<DuongDi[i]<<" --> ";
	cout<<DuongDi[i]<<endl;
}
void XuatMTKe(GRAPH &g){
	cout<<"So dinh cua do thi: "<<g.sodinh;
	printf("\nMa tran ke:\n");
	for (int i = 0; i<g.sodinh; i++){
		for (int j = 0; j<g.sodinh; j++)
			printf("%3d ", g.a[i][j]);
		printf("\n");
	}
}
int main(){
	GRAPH g;
	FILE *f = fopen("Lab06_Dijktra_Di_Tu_X_Den_Y.txt", "rt");
	if (f == NULL){
		printf("Doc file loi !!!");
		return 0;
	}
	fscanf(f, "%d", &g.sodinh);
	for (int i = 0; i<g.sodinh; i++)	{
		for (int j = 0; j<g.sodinh; j++){
			fscanf(f, "%d", &(g.a[i][j]));
		}
	}
	XuatMTKe(g);
	int x, y;
	//x = 0; y = 4;
    //"Nhap dinh dau va dinh cuoi: "; 
    cout<<"Dijktra di tu x den y:"<<endl;
    cout<<"Nhap x: "; cin>>x;
    cout<<"Nhap y: "; cin>>y;
	Dijkstra(g, x, y);
	//cout<<"Duong di ngan nhat tu "<<x<<" den "<<y<<" la: "<<endl;
	Xuat(x, y);
	return 0;
}

