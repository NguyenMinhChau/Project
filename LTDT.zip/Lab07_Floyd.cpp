#include <iostream>
using namespace std;
 
#define MAX 100 //so dinh toi da cua do thi

struct GRAPH { 
	int sodinh;//so dinh do thi
	int a[MAX][MAX];//ma tran ke	
}; 

//Khai bao prototype
void Floyd(GRAPH g);
void InDuongDi(int iDau, int iCuoi);

int L[MAX][MAX];
int Previous[MAX][MAX];
//Tim duong di ngan nhat giua tat ca cap dinh
void Floyd(GRAPH g){
	int i, j, k;

	for(i = 0; i < g.sodinh; i++){
		for(j = 0; j < g.sodinh; j++)
		{
			L[i][j] = g.a[i][j];
			Previous[i][j] = i;
		}
		for(k = 0; k < g.sodinh; k++){
		    for(i = 0; i < g.sodinh; i++){
				if(L[i][k] > 0){
					for(j = 0; j < g.sodinh; j++){
						if(L[k][j] > 0){
							if(((L[i][j] == 0) && (i != j)) || (L[i][j] > L[i][k] + L[k][j])){
							    L[i][j] = L[i][k] + L[k][j];
							    Previous[i][j] = Previous[k][j];
						    }
						}
					}	    
				}
			}	
		}		
	}			
}
//In ra duong di ngan nhat giua hai dinh bat ki
void InDuongDi(int iDau, int iCuoi) {
	if(L[iDau][iCuoi] <= 0) {
		cout<<"Khong co duong di..."<<endl; return;
	}

	cout<<"Chi phi: "<<iDau<<" --> "<<iCuoi<<" = "<<L[iDau][iCuoi]<<endl;
	cout<<"Duong di ngan nhat tu "<<iDau<<" den "<<iCuoi<<" la: ";		

	int DuongDi[MAX];
	int i = 0, d = iCuoi, j;
	
	DuongDi[0] = iCuoi;
	i++;	
	while(iDau!= d)	{		
		DuongDi[i] = Previous[iDau][d];
		i++;
		d = Previous[iDau][d];
	}
	DuongDi[i] = iDau;	
	//Xuat nguoc de t�m duong di dinhDau -> dinhCuoi
	for(j = i-1; j > 0; j--)
		cout<<DuongDi[j]<<" --> ";
	cout<<DuongDi[j]<<endl;
}


void XuatMTKe(GRAPH &g){
	cout<<"So dinh cua do thi: "<<g.sodinh;
	printf("\nMa tran ke:\n");
	for (int i = 0; i<g.sodinh; i++){
		for (int j = 0; j<g.sodinh; j++)
			printf("%3d ", g.a[i][j]);
		printf("\n");
	}
}
int main(){
	GRAPH g;
	FILE *f = fopen("Lab07_Floyd.txt", "rt");
	if (f == NULL){
		printf("Doc file loi !!!");
		return 0;
	}
	fscanf(f, "%d", &g.sodinh);
	for (int i = 0; i<g.sodinh; i++)	{
		for (int j = 0; j<g.sodinh; j++){
			fscanf(f, "%d", &(g.a[i][j]));
		}
	}
	XuatMTKe(g);
	int x,y;
	cout<<"Nhap dinh dau: "; cin>>x;
	cout<<"Nhap dinh cuoi: "; cin>>y;
	Floyd(g);//tim duong di ngan nhat tu x toi y
	InDuongDi(x, y);//In duong di ngan nhat tu x toi y
	system("pause");
	return 0;
}	

