#include<iostream>
using namespace std;
struct node{
	int data;
	node *next;
};

node *createNode(int x){
    node *temp = new node;
    temp->next = NULL;
    temp->data = x; 
    return temp;
}

void printList(node *l){
	node *p = l;
	int dem=0;
	while (p != NULL){
		cout << p->data << " ";
		dem++;
		p = p->next;
	}
	cout<<endl;
	cout<<"So luong phan tu cua mang (duoc cap nhat): "<<dem;
}
node *addElement(node*p, int x){
	node *temp = createNode(x);
	p->next = temp;
	return temp;
}
//Section 1 Th�m
node *addHead(node *l, int x){
	node *temp = new node;
	temp->data = x;
	temp->next = l;
	l = temp;
	return l;
}

node *addAt(node *l, int k, int x){
	node *p = l;
	for (int i = 1; i < k-1; i++){
		p = p->next;
	}
	node *temp = new node;
	temp->data = x;
	temp->next = p->next;
	p->next = temp;
	
	return l;
}

node *addTail(node *l, int x){
	node *p = l;
	while (p->next != NULL){
		p= p->next;
	}
	node *temp = new node;
	temp->data = x;
	temp->next = NULL;
	p->next = temp;
	return l;
}
//Section 2 X�a
node *deleteHead(node *l){
	node *p = l;
	p = p->next;
	delete(l);
	return p;
}

node *deleteTail(node *l){
	node *p = l;
	while (p->next->next != NULL){
		p = p->next;
	}
	delete(p->next);
	p->next = NULL;
	return l;
}

node *deleteAt(node *l, int k){
	node *p = l;
	for (int i = 0; i < k-1; i++){
		p = p->next;
	}
	node *temp = p->next;
	p->next = p->next->next;
	delete(temp);
	return l;
}
//Section 3 Xuat PT thu index
node *XuLi(node *p, int k){
    node *l=p;
    for(int i=0;i<k;i++){
        l=l->next;
    }
    return l;
}
int main(){
    //Section 1
    
	int n, x, k, v;
	cout<<"Moi nhap so luong phan tu cua mang: "; cin >> n;
	cout<<"Moi ban nhap mang: ";
	cin >> x;
	node *l = createNode(x);
	node *p = l;
	for (int i = 1; i < n; i++){
		cin >> x;
		p = addElement(p, x);
	}
	cout<<"Moi nhap gia tri can them: "; cin>>v;
	cout<<"Moi nhap vi tri muon them: "; cin>>k;
	if (k == 0){
		l = addHead(l, v);	
	} else if (k == n){
		l = addTail(l, v);
	} else{
		l = addAt(l, k, v);
	}
	cout<<"Mang sau khi cap nhat: ";
	printList(l);
	
	//Section 2
	
	/*int n, x, k;
	cout<<"Moi nhap so luong phan tu cua mang: "; cin >> n;
	cout<<"Moi ban nhap mang: ";
	cin >> x;
	node *l = createNode(x);
	node *p = l;
	for (int i = 1; i < n; i++){
		cin >> x;
		p = addElement(p, x);
	}
	cout<<"Moi nhap vi tri can xoa: "; cin>>k;
	if (k == 0){
		l = deleteHead(l);	
	} else if (k == n-1){
		l = deleteTail(l);
	} else{
		l = deleteAt(l,k);
	}
	cout<<"Mang sau khi cap nhat: ";
	printList(l);*/
	
	//Section 3
	
	/*int n, x, k;
	cout<<"Moi nhap so luong phan tu mang: "; cin >> n;
	cout<<"Moi ban nhap mang: ";
	cin >> x;
	node *l = createNode(x);
	node *p = l;
	for (int i = 1; i < n; i++){
		cin >> x;
		p = addElement(p, x);
	}
	cout<<"Moi nhap vi tri can xuat: "; cin>>k;
    p=XuLi(l,k);
    cout<<"Phan tu can xuat co gia tri la: "<<p->data;*/
	return 0;
}
