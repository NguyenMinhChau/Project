#include<iostream>
#include<string>
using namespace std;
int main(){
    string a; cin>>a;
    string b;
    char max=a[0];
    for(int i=0;i<a.length();i++){
        if(a[i]>max) max=a[i];
    }
    for(int i=0;i<=max;i++){
        b[i]=0;
    }
    for(int i=0;i<a.length();i++){
        b[a[i]]+=1;
    }
    for(int i=0;i<=max;i++){
        if(b[i]>0){
            cout<<(char)i<<" Xuat Hien "<<(int)b[i]<<" Lan"<<endl;
        }
    }
    return 0;
}
