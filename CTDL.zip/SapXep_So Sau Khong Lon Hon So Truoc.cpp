#include<iostream>
using namespace std;
void XuLi(int *a, int n){
    int i,j,k,temp;
    for(i=n/2;i>0;i/=2){
        for(j=i;j<n;j++){
            temp=a[j];
            for(k=j;k>=i && a[k-i]>temp;k-=i){
                a[k]=a[k-i];
            }
            a[k]=temp;
        }
    }
}
int main(){
    int n; 
	cout<<"Moi nhap so luong phan tu cua mang: "; cin>>n;
    int *a=new int [n];
    cout<<"Moi nhap mang: ";
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    XuLi(a,n);
    cout<<"Ket qua: ";
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
    }
    return 0;
}
