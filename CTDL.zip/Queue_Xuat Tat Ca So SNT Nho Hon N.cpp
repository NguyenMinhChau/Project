#include<iostream>
#include<queue>
#include<math.h>

using namespace std;

bool isPrime(int n){
	if (n<2) return false;
	for (int i=2; i<=sqrt(n); i++)
	if (n%i==0) return false;
	return true;
}
int main(){
    queue<int> q;
    int n; 
    cout<<"Moi ban nhap n: "; cin >> n;
    for (int i = 2; i <= n, i < 10; i++){
        if (isPrime(i)){
            q.push(i);
        }
    }
    cout<<"Cac so Sieu Nguyen To nho hon n: ";
    while (!q.empty()){
        for (int i = 1; i <= 9; i++){
            int k = q.front()*10 + i;
            if ( k <= n && isPrime(k)){
                q.push(q.front()*10 + i);
            }
        }
        cout << q.front() << " ";
        q.pop();
    }

    return 0;
}
