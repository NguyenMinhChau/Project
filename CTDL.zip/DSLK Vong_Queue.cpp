//DSLK Vong
#include<iostream>
using namespace std;
struct node{
	int data;
	node *next;
};
node *createNode(int x){
    node *temp = new node;
    temp->next = temp;
    temp->data = x; 
    return temp;
}
void printList(node *l, int k){
	node *p = l;
	cout<<"Mang duoc cap nhat: ";
	for (int i = 0; i < k; i++){
		p = p->next;
	}
	cout << p->data << " ";
	node *p2 = p->next;
	while (p2 != p){
		cout << p2->data << " ";
		p2 = p2->next;
	}
}
node *addTail(node *l, int x){
	node *p = l;
	while (p->next != l){
		p = p->next;
	}
	node *temp = new node;
	temp->data = x;
	temp->next = l;
	p->next = temp;
	p = temp;
	return l;
}
int main(){
	int n, x, k;
	cout<<"Moi nhap so luong phan tu cua mang: "; cin >> n;
	cout<<"Moi ban nhap mang: ";
	cin >> x;
	node *l = createNode(x);
	node *p = l;
	for (int i = 1; i < n; i++){
		cin >> x;
		l = addTail(l, x);
	}
	cout<<"Moi nhap gia tri yeu cau: "; cin>>k;
	printList(l, k);
	return 0;
}

//Hang Doi Queue
/*#include<iostream>
#include<queue>
using namespace std;
int main(){
    int n,temp,k;
    cout<<"Moi nhap so luong phan tu cua mang: "; cin>>n;
    queue<int> a;
    for(int i=0;i<n;i++){
        cin>>temp;
        a.push(temp);
    }
    cout<<"Moi nhap vi tri yeu cau: "; cin>>k;
    for(int i=0;i<k;i++){
        int x=a.front();
        a.pop();
        a.push(x);
    }
    cout<<"Mang duoc cap nhat: ";
    while(!a.empty()){
        cout<<a.front()<<" ";
        a.pop();
    }
    return 0;
}*/
